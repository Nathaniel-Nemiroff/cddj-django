from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

from django.db.models import Count

def index(request):
	'''context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
	}'''

	'''context = {

		"baseball_leagues":League.objects.filter(sport="Baseball"),
		"womens_leagues":League.objects.filter(name__contains="Women"),
		"hockey_leagues":League.objects.filter(sport__contains="Hockey"),
		"not_football_leagues":League.objects.exclude(sport="Football"),
		"conference_leagues":League.objects.filter(name__contains="conference"),
		"atlantic_leagues":League.objects.filter(name__contains="Atlantic"),
		"dallas_teams":Team.objects.filter(location="Dallas"),
		"raptor_teams":Team.objects.filter(team_name="Raptors"),
		"city_teams":Team.objects.filter(location__contains="City"),
		"T_teams":Team.objects.filter(team_name__startswith="T"),
		"ordered_location_teams":Team.objects.all().order_by('location'),
		"reverse_ordered_teams":Team.objects.all().order_by('-team_name'),
		"cooper_players":Player.objects.filter(last_name="Cooper"),
		"joshua_players":Player.objects.filter(first_name="Joshua"),
		"cooper_not_joshua_players":Player.objects.filter(last_name="Cooper").exclude(first_name="Joshua"),
		"alexander_or_wyatt_players":Player.objects.filter(first_name="Alexander")|Player.objects.filter(first_name="Wyatt")

	}'''

	context = {

		'ASC_teams':Team.objects.filter(league=League.objects.filter(name="Atlantic Soccer Conference")),
		'curr_BP_players':Player.objects.filter(curr_team=Team.objects.filter(team_name="Penguins", location="Boston")),
		'curr_ICBC_players':Player.objects.filter(curr_team=Team.objects.filter(league=League.objects.filter(name="International Collegiate Baseball Conference"))),
		'curr_ACAF_lopez_players':Player.objects.filter(last_name="Lopez", curr_team=Team.objects.filter(league=League.objects.filter(name="American Conference of Amateur Football"))),
		'football_players':Player.objects.filter(all_teams=Team.objects.filter(league=League.objects.filter(sport="Football"))),
		'curr_sophia_teams':Team.objects.filter(curr_players__first_name="Sophia"),
		'curr_sophia_leagues':League.objects.filter(teams=Team.objects.filter(curr_players__first_name="Sophia")),
		'florez_nWR_ncurr_players':Player.objects.filter(last_name="Flores").exclude(curr_team=Team.objects.filter(team_name="Roughriders", location="Washington")),
		'samuel_evens_teams':Team.objects.filter(all_players__first_name="Samuel", all_players__last_name="Evans"),
		'MTC_players':Player.objects.filter(all_teams=Team.objects.filter(team_name="Tiger-Cats", location="Manitoba")),
		'WV_ncurr_players':Player.objects.filter(all_teams__team_name="Vikings", all_teams__location="Wichita").exclude(curr_team__team_name="Vikings", curr_team__location="Wichita"),
		'jacob_gray_ncurr_teams':Team.objects.filter(all_players__first_name="Jacob", all_players__last_name="Gray").exclude(curr_players=Player.objects.filter(first_name="Jacob", last_name="Gray")),
		'joshua_AFABP_players':Player.objects.filter(first_name="Joshua", all_teams=Team.objects.filter(league=League.objects.filter(name="Atlantic Federation of Amateur Baseball Players"))),
		'12plus_teams':Team.objects.annotate(num_players=Count('all_players')).filter(num_players__gt=12),
		'sorted_players':Player.objects.annotate(num_teams=Count('all_teams')).order_by('num_teams')

	}

	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
